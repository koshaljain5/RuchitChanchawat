import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Assert;
import org.testng.annotations.*;

import io.github.bonigarcia.wdm.WebDriverManager;

public class TestClass {

	private WebDriver webdriver;
	@BeforeClass
	public static void beforeClass()
	{
	    WebDriverManager.chromedriver().setup();
	}
	
	@BeforeMethod
	public void beforeMethod()
	{
	    webdriver=new ChromeDriver();
	    webdriver.manage().window().maximize();
	    webdriver.get("https://app.preprod.glide.health/");
	}

	@Test
	public  void TC001_VerifyTitle()
	{
	    Assert.assertEquals(webdriver.getTitle(), "Glide Health","title mismatch");
	}
	
	@Test
	public  void TC002_VerifyLoginForm()
	{
	    String text = webdriver.findElement(By.cssSelector("div.login-form-area h1")).getText();
	    Assert.assertEquals(text, "Log In to Your Account","Login form text mismatch");
	}
	
	@Test
	public void TC003_VerifyLogin() 
	{
		webdriver.findElement(By.xpath("//input[@id='login_email']")).sendKeys("ruchitchanchawat@gmail.com");
		webdriver.findElement(By.xpath("//input[@id='login_password']")).sendKeys("ruchitchanchawat@gmail.com");
		webdriver.findElement(By.xpath("//button[@type='submit']")).click();
		int count = webdriver.findElements(By.cssSelector("div.ant-alert-message")).size();
		Assert.assertTrue(count > 0,"Login wasn't successfull");
	}
	
	@AfterMethod
	public void afterMethod()
	{
		webdriver.close();
	}
}
